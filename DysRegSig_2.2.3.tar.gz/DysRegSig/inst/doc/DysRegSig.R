## ---- eval = FALSE------------------------------------------------------------
#  if(!require(BiocManager)) install.packages("BiocManager")
#  library(BiocManager)
#  install(c('limma','survcomp'))

## ---- eval = FALSE------------------------------------------------------------
#  if(!require(devtools)) install.packages("devtools")
#  devtools::install_github('SCBIT-YYLab/DysRegSig')

## ---- eval = FALSE------------------------------------------------------------
#  library(DysRegSig)

## ---- eval = FALSE------------------------------------------------------------
#  data(ExpData)
#  ExpData[1:5,1:5]
#  
#  data(tf2tar)
#  head(tf2tar)
#  
#  data(ClinData)
#  head(ClinData)
#  
#  group.1 <- ClinData$sample[which(ClinData$binaryResponse == 'CR/PR')]
#  exp.1 <- ExpData[,colnames(ExpData) %in% group.1]
#  
#  group.2 <- ClinData$sample[which(ClinData$binaryResponse == 'SD/PD')]
#  exp.2 <- ExpData[,colnames(ExpData) %in% group.2]
#  
#  dysreg.out <- DysReg(exp.1 = exp.1, exp.2 = exp.2, tf2tar,
#                       de.genes = NULL, de.pval = 0.05,
#                       grn.method = 'Boruta',
#                       pValue = 0.01, ci = 0.90, verbose = T)
#  
#  dysreg.res <- dysreg.out$dysreg
#  head(dysreg.res)
#  

## ---- eval = FALSE------------------------------------------------------------
#  diffcor.res <- DiffCor(exp.1 = exp.1, exp.2 = exp.2, tf2tar,
#                         cor.method = 'pearson', p.adj = 'BH',
#                         verbose = TRUE)
#  
#  ## set cutoff
#  diffcor.res <- subset(diffcor.res,p.val < 0.05)
#  head(diffcor.res)

## ---- eval = FALSE------------------------------------------------------------
#  
#  diffcor.p.res <- DiffCorPlus(exp.1 = exp.1,exp.2 = exp.2, tf2tar,
#                               de.genes = NULL, de.pval = 0.05,
#                               cor.method = 'pearson', p.adj = 'BH')
#  
#  ## set cutoff
#  diffcor.p.res <- subset(diffcor.p.res,p.val < 0.05)
#  head(diffcor.p.res)

## ---- eval = FALSE------------------------------------------------------------
#  plotDysregExp(tf = dysreg.res$TF[1], tar = dysreg.res$Target[1],
#                exp.1 = exp.1, exp.2 = exp.2,
#                exp1.label = 'Response', exp2.label = 'No-response',
#                dysreg = dysreg.res, method ='DysReg',
#                conf.int.level = 0.95)

## ---- eval = FALSE------------------------------------------------------------
#  reg.rank <- RankDysReg(dysreg.res)
#  head(reg.rank)
#  

## ---- eval = FALSE------------------------------------------------------------
#  tf.rank <- RankDysTF(dysreg.res)
#  head(tf.rank)
#  

## ---- eval = FALSE------------------------------------------------------------
#  dysreg <- dysreg.res[,1:2]
#  
#  pheno.data <- ClinData[,c("sample", "binaryResponse")]
#  pheno.data <- pheno.data[!is.na(pheno.data$binaryResponse),]
#  colnames(pheno.data)[2] <- "clin.factor"
#  head(pheno.data)
#  
#  ## use genetic algorithm to search the best combination of dysregulations
#  combdysreg.out <- combineDysreg(dysreg = dysreg, exp.data = ExpData,
#                                  fitness.func = 'fitness.AUC',
#                                  pheno.data = pheno.data,
#                                  pop.size = 1000, select.rate=0.2,
#                                  mut.rate=0.1, add.rate=0.1,
#                                  topN = 10, train.rate = 0.6, iter = 100)
#  
#  ## Check the output of combineDysreg
#  best.fit <- combdysreg.out$best.fitness
#  best.individ <- combdysreg.out$individ
#  head(best.fit)
#  
#  ## THe example for selceting the gene dysregulations that are robustly associated with the phenotype.
#  
#  # calculate the frequence of each each dysregualtion among the top N best individuals
#  freq.res <- vector()
#  for(i in 1:100){
#    start <- 10*i-9
#    end <- 10*i
#    iter.i <- best.individ[start:end,]
#    iter.i <- colSums(iter.i)/10
#    freq.res <- rbind(freq.res,iter.i)
#  }
#  freq.res <- t(freq.res)
#  colnames(freq.res) <- c(1:100)
#  rownames(freq.res) <- paste(dysreg$TF,dysreg$Target,sep = '-')
#  
#  # visualize the frequence of each each dysregualtion among the top N best individuals
#  pheatmap(freq.res,color = colorRampPalette(c('lightyellow',"orange", "firebrick3"))(1000),
#           display_numbers = F, cluster_rows = F,cluster_cols = F,
#           fontsize_row = 8, fontsize_col = 10)
#  
#  # choose the dysregulations frequently emerged among the top N best individuals as signatures
#  marker.dsyergulations <- rownames(freq.res)[freq.res[,100] >= 0.9]
#  

## ----label='Session information', eval=TRUE, echo=FALSE-----------------------
sessionInfo()

